/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int arr[100], n, pos, x;
    cout << "Enter the size of the array: ";
    cin >> n;
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    cout << "Enter the position where you want to insert the element: ";
    cin >> pos;
    if (pos > n) {
        cout << "Invalid input";
        return 0;
    }
    cout << "Enter the element you want to insert: ";
    cin >> x;
    for (int i = n - 1; i >= pos - 1; i--) {
        arr[i + 1] = arr[i];
    }
    arr[pos - 1] = x;
    cout << "The new array is: ";
    for (int i = 0; i <= n; i++) {
        cout << arr[i] << " ";
    }
    return 0;
}
